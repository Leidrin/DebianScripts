############
Auto-Update:
############

You can use the provided script (updates.sh) to update your server. To use, run these two commands:

chmod +x updates.sh
sudo ./updates.sh

####
GUI:
####

If you wish to add a GUI (Graphical User Interface) to your server, you can use the script in this directory (gui-debian-prep.sh).

The GUI included in this script is XFCE4, a lightweight User Interface which offers modern comforts at low resource costs. You may opt to install a different GUI if desired, however XFCE4 should suit most user's needs.

**We recommend taking a snapshot of your VM before running the script if you have configured the server already, in case of any conflicts with the new packages**

To install, run these two commands:

chmod +x gui-debian.prep.sh
sudo ./gui-debian-prep.sh

The script will self-delete when install finishes.