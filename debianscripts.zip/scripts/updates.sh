#!/bin/bash
# Check if script is running as root first
if [[ "$(whoami)" != "root" ]]; then
  echo "$(tput setaf 1)Script must be ran as root! Example: sudo ./updates.sh$(tput sgr 0)"
  exit 1
fi

apt update
apt upgrade -y
apt autoremove -y
apt clean

echo "$(tput setaf 6)Update process finished. Reboot server (sudo reboot) if packages updated.$(tput sgr 0)"
